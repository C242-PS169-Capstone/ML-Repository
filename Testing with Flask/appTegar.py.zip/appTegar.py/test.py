import requests

# URL endpoint
url = "http://127.0.0.1:5000/predict"

# Data JSON
data = {"text": "I want to eat chicken so I kill it."}

# Header
headers = {"Content-Type": "application/json"}

# Kirim permintaan POST
response = requests.post(url, json=data, headers=headers)

# Cetak hasil
if response.status_code == 200:
    print("Prediction:", response.json()['prediction'])
    print("Confidence:", response.json()['confidence'])
else:
    print("Error:", response.json())
